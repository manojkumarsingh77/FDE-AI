# Release Readiness and Dependency Risk Agent (Track B)

## Scenario

You are joining the FedEx Shipping Platform team mid-sprint. The team runs a
release pipeline that has been in production for several months. Until now, the
deploy gate (in `pipeline/deploy.py`) only checks CI pass/fail. Two recurring
post-release incidents prompted leadership to expand the gate:

1. A deployment shipped with a HIGH-severity CVE in a transitive dependency that
   was caught only after a security scan ran post-deploy.
2. A major version bump landed in production with breaking API changes that were
   never documented in the changelog. Downstream teams were not notified.

Your task: integrate a **release readiness agent** into the existing pipeline. The
agent scans dependencies for known vulnerabilities, checks for open blocking
tickets, and validates changelog coherence. It produces a structured recommendation
(**release**, **hold**, or **escalate**) with written rationale that a release
manager can act on before the deploy gate runs.

The agent's output is advisory. The deploy gate and the human release manager
remain the final decision-makers. The agent must be reliable, explainable, and
consistent.

## Acceptance Criteria

These items are grouped by the six categories of the FedEx Capstone Rubric (v5.0).
At certification, each category must clear an 80% bar to pass; teams should target
100%. Items below each heading must be true for that category to count as met.

### Category 1: Agent functionality and correctness

- [ ] The agent accepts a `ReleaseRequest` as input and returns a `ReleaseRecommendation`
- [ ] The recommendation is always one of `release`, `hold`, or `escalate`
- [ ] Every recommendation includes a non-empty `rationale` referencing which check(s) drove the decision
- [ ] The agent performs all four checks: dependency CVE scan, blocking ticket query, changelog coherence, CI gate
- [ ] All three decision types are reachable using the provided sample requests in `mock_data/release_requests.json`
- [ ] The agent runs end to end on all 9 sample release requests without crashing or unhandled exceptions
- [ ] Tool docstrings are clear enough that the agent reliably selects the correct tool for each check
- [ ] The functional pipeline modules (`runner.py`, `deploy.py`, `changelog_reader.py`) continue to pass their tests; `python -m pipeline.runner` output matches Session 1 baseline

### Category 2: Spec-driven design quality

- [ ] An OpenSpec change directory `openspec/changes/add-release-readiness-agent/` exists, produced by `/opsx-propose`
- [ ] `openspec/changes/add-release-readiness-agent/proposal.md` is coherent: states why the change is being made, what is changing (capabilities added, modified, or removed) including the stub implementations being filled in, and what the impact is on the existing pipeline
- [ ] `openspec/changes/add-release-readiness-agent/specs/` contains delta specs for every capability authored (models, data loader, dependency scanner stub fill-in, ticket client stub fill-in, tool wrappers, agent wiring) with measurable acceptance criteria
- [ ] `openspec/changes/add-release-readiness-agent/design.md` documents the architectural decisions (decision priority for release/hold/escalate, why the agent stays advisory, how stubs integrate with the existing functional modules)
- [ ] `openspec/changes/add-release-readiness-agent/tasks.md` lists the implementation steps and is fully checked off when implementation is complete
- [ ] `openspec validate add-release-readiness-agent` (or `openspec validate --all`) passes with no structural failures
- [ ] Pydantic models match the delta spec exactly (typed fields, validators, allowed values for `decision`)
- [ ] Commit history shows the OpenSpec proposal authored before its implementation, not backfilled

### Category 3: Engineering quality

- [ ] Tool-level test coverage in `tests/` (not just the agent class)
- [ ] Tests cover decision logic and edge cases, including at least one partial-data scenario
- [ ] Tool errors have a defined fallback path: when a tool is unavailable or fails, the agent returns a partial recommendation with the failure surfaced in the rationale, not a generic error
- [ ] Schema validation on agent inputs and outputs; out-of-policy inputs trigger a refusal or escalation rather than a silent pass
- [ ] No hardcoded secrets or credentials in the repository
- [ ] Code is readable: docstrings on every public function, named constants for magic numbers, naming reflects intent
- [ ] pytest suite passes covering at minimum: release, hold (CI fail), hold (blocking ticket), and escalate (CRITICAL CVE)

### Category 4: RAPID controls execution (ITC.009 and ITC.004)

- [ ] `docs/rapid-peer-review.md` exists with all six RAPID Code Work Product criteria rated and a summary recommendation (approved / approved with conditions / not approved)
- [ ] All Fail findings in the peer review are resolved; all Needs Attention findings are resolved or formally accepted with written rationale
- [ ] `docs/go-no-go-checklist.md` is completed with every section filled: requirements, code review, test results, outstanding issues, backout plan, decision
- [ ] The Go/No-Go Decision Rationale is evidence-backed (specific test counts, peer review rating, acceptance criteria status), not asserted
- [ ] The agent's own `release` / `hold` / `escalate` recommendation and the team's Go/No-Go checklist decision are compared explicitly; the comparison notes where they align, where they diverge, and why (brownfield-specific)
- [ ] The agent does not directly invoke `pipeline/deploy.py`; all deploy gate calls go through `tools/release_tools.py`

### Category 5: AI-assisted development practice

- [ ] `.github/copilot-instructions.md` is present, coherent, and reflects the project (not the starter template left untouched)
- [ ] Commit history is preserved and inspectable: no force-pushes that erased iteration, no squashed branches that hide the build sequence
- [ ] A `prompts.md` (or equivalent) in the repository captures the prompts that produced the key components
- [ ] OpenSpec proposal iteration is visible in the commit history: proposals evolved through commits, they were not backfilled at the end
- [ ] (Showcase prep) The team can name one instance where they redirected or rejected Copilot output, and why
- [ ] (Showcase prep) The team can name where Copilot helped them move faster and where they had to step in and correct it

### Category 6: Demonstration and communication

- [ ] The team delivers a 3 to 5 minute demonstration within the allotted time
- [ ] The team explains why they made specific design choices, not just what they did
- [ ] The team identifies what they would do differently with more time
- [ ] The team answers the structured debrief question live without deferring entirely to slides
- [ ] The demo is framed for a FedEx stakeholder audience, not for peers

## Project Structure

```
release-agent/
├── agent.py              # Pydantic AI agent definition (you build this)
├── models.py             # ReleaseRequest and ReleaseRecommendation models (you build this)
├── tools/                # Agent tool functions (you build this)
├── data/
│   └── loader.py         # Mock data loader (you build this)
├── tests/                # Test suite (you build this)
├── pipeline/             # Brownfield pipeline; read carefully before modifying
│   ├── __init__.py
│   ├── runner.py         # Functional: pipeline orchestrator
│   ├── deploy.py         # Functional: deploy gate (CI pass/fail check)
│   ├── changelog_reader.py   # Functional: CHANGELOG.md parser
│   ├── dependency_scanner.py # STUB: implement this as an agent tool
│   └── ticket_client.py      # STUB: implement this as an agent tool
├── mock_data/            # Reference data; do not modify
│   ├── cve_database.json
│   ├── tickets.json
│   ├── ci_results.json
│   ├── release_requests.json
│   ├── requirements_shipping_api.txt
│   ├── requirements_label_service.txt
│   ├── requirements_notification_service.txt
│   └── CHANGELOG.md
├── openspec/             # Spec-driven development artifacts (you populate this)
│   └── pipeline-architecture.md   # Pre-authored spec of existing pipeline
├── docs/                 # RAPID compliance documents (templates provided)
│   ├── rapid-peer-review.md
│   └── go-no-go-checklist.md
├── .github/
│   ├── copilot-instructions.md  # Project conventions (read by Copilot at runtime)
│   └── skills/
│       └── rapid-peer-review.md # RAPID peer review Agent Skill
└── prompts.md                   # Capture the prompts that produced key components (you fill in)
```

## Getting Started

See the lab guide for step-by-step instructions. Complete environment setup before Session 1.

### Quick start

```bash
# Install dependencies
uv pip install -e ".[dev]"

# Verify the existing pipeline runs
python -m pipeline.runner

# Run tests
pytest tests/ -v
```

## Data Reference

The `mock_data/` directory contains:
- **12 CVEs** across common Python packages (HIGH and CRITICAL severity entries present)
- **15 tickets** across 6 components, with blocking and non-blocking variants
- **8 CI run records** across 3 components, including passing and failing builds
- **9 sample release requests** designed to produce all three decision outcomes
- **3 component requirements files** with intentional vulnerability variation
- **1 CHANGELOG.md** with a major-version coherence gap in the v3.0.0 entry

Review `release_requests.json` carefully during Session 1. The `expected_outcome`
and `outcome_reason` fields explain what each sample request is designed to test.

## Decision Rules

The agent must implement these rules consistently (see `.github/copilot-instructions.md`
for the full decision table):

| Signal | Decision |
|--------|----------|
| CRITICAL CVE | escalate |
| HIGH CVE + blocking ticket | escalate |
| Major version, no breaking-change docs | escalate |
| HIGH CVE only | hold |
| Blocking ticket only | hold |
| CI test failures | hold |
| All checks pass | release |
